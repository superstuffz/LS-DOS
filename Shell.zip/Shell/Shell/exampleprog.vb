﻿Public Class exampleprog
    Function exec()
        ctext("Hello World", ConsoleColor.Blue)
        Return True
    End Function
End Class
